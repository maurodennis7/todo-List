import { showElement, hideElement } from "./hide.js";

const span = document.querySelector("span");
// editar tarefas também

const tarefas = [];
const list = document.querySelector("#list");
const tarefa = document.querySelector("input#tarefa");

document.querySelector("button#add").addEventListener("click", () => {
    verificar(list, tarefa);
    limparInput(tarefa);
    verifyChild(list);
});

// verificar o input
function verificar(list, input){
    input.value !== '' ?createLi(list, input):erro(input);
}
// criar a Li
function createLi(list, input){
    tarefas.push(input.value);

    const li = document.createElement("li");
    const btnRemove = createBtnRemove();

    for(let valor of tarefas){
        li.textContent = `${valor}`;
        li.appendChild(btnRemove);
        list.appendChild(li);
    }

    btnRemove.addEventListener("click", () => {
        deleteItem(tarefas, li);
    });
}

// criar buttton remover tarefa
function createBtnRemove(){
    const btnRemove = document.createElement("button");
    btnRemove.innerHTML = `<img src="./images/trash.svg" alt="Trash">`;
    btnRemove.classList.add('btnRemove');

    return btnRemove;
}
// deletar um item da lista
function deleteItem(array, li){
    const pos = array.indexOf(li.textContent);
    tarefas.splice(pos, 1);
    list.removeChild(li);

    verifyChild(list);
}
// msg de erro
function erro(input){
    alert("Preencha primeiro o campo");
    input.focus();
}
//limpar o input
function limparInput(input){
    input.value = '';
    input.focus();
}
// Add via teclado
document.addEventListener("keydown", (event) => {
    if(event.key === 'Enter'){
        verificar(list, tarefa);
        verifyChild(list);
        limparInput(tarefa);
    }
});

function verifyChild(list){
    if(list.childElementCount > 1){
        hideElement(span);
    }

    if(list.childElementCount === 1){
        showElement(span);
    }   
}